# Cricket Coach 26 — Schedule/Calendar Audit

## Scope
Static review of the uploaded project, with the season transition, calendar generator, match-launch flow, match completion persistence, and season schedule/archive view as the priority. Existing features were retained; no application rewrite was performed.

## Confirmed defects found and addressed

1. **Match completion could mark the wrong fixture complete.** `recordCompletedMatch` previously marked a fixture when its index equaled `currentDateIndex` OR when its teams matched the finished match. Auto-advance can change the index before the completion effect runs, and IPL opponents can meet twice. This could mark the next fixture or both meetings complete. Matches now carry `scheduledFixtureId`, and completion updates only that exact fixture.
2. **Match-day opponent resolution could disagree with the fixture.** `HubScreen` preferred `opponentTeamId` over the actual fixture's home/away team IDs. Fixture participants and home/away are now authoritative on match days.
3. **Scheduled format could be overridden by the global format selector.** Starting a scheduled fixture now uses `matchFixture.format` when present.
4. **Schedule/archive used a disconnected static list.** The archive marked the first N static fixtures complete from standings totals and attached calendar results by array index; it also filtered `eventType === 'match'` although generated dates use `type`. The schedule now reads the active league's actual calendar fixtures and their saved result/scorecard state.
5. **Schedule modal could read the wrong league.** It used `leagues[0]` rather than the active league. It now resolves by `currentLeagueId`.
6. **New seasons reused stale year/date data.** `startNewSeason` defaulted to 2027 every time and passed an optional `nextYear` directly to the calendar builder. It now derives the next year from the active league unless explicitly provided, writes `seasonYear`, synchronizes league teams, and builds dates for that resolved year. Calendar advancement, date selection, and match creation also resolve the actual active league instead of assuming the default ID is always present.
7. **Calendar dates were not guaranteed to be chronological and weekdays were hardcoded.** International-only dates were appended after domestic dates; later-season weekdays assumed April 17 was always Friday. Dates are now sorted and date labels/weekday values are derived from UTC calendar dates.
8. **2026 international fixtures leaked into later seasons.** The bundled international tour list is specifically for 2026; the generator now only uses entries matching the requested season year.
9. **Calendar advancement wrapped from the final day to Day 0.** It now clamps at the final date and avoids repeatedly applying end-of-calendar effects once no fixtures remain pending.

## Regression coverage added

- Calendar dates are chronologically sorted.
- Domestic fixture opponent/home-away metadata matches the actual fixture.
- A 2027 calendar contains no stale 2026 dates and has correct weekdays.
- Repeated home/away meetings are resolved by exact scheduled fixture ID, not by team pair or current index.

## Validation performed

- TypeScript/TSX syntax transpilation: **53 files parsed, zero syntax diagnostics**.
- Isolated calendar-generator checks: **2026 and 2027 passed** chronological order, year consistency, weekday consistency, 14 user fixtures, and opponent/home-away checks.
- Full `npm run lint` / `npm test` / production build: **not completed**. Dependency installation did not finish in this environment, leaving required type packages (`vite/client`, `vite-plugin-pwa/client`, and `@types/node`) unavailable. These checks must be run in an environment with dependencies installed before treating the patch as fully runtime-verified.

## Remaining caveat

The in-game career calendar is a generated schedule (14 user fixtures plus concurrent AI fixtures). The old static IPL 2026 fixture dataset was not wired to match simulation, which caused the mismatch. The schedule/archive now reflects the actual career calendar so played matches and displayed results agree. If the product requirement is to reproduce every official IPL fixture and date exactly, that is a separate schedule-data integration task; the static list should not be presented as the playable calendar until it drives the same fixture engine.
